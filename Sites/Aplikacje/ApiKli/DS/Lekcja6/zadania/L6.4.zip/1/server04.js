var express = require("express");
var app = express();
var path = require("path");
var bodyParser = require("body-parser")
const PORT = 3000;

let users = [
    {nick:"111", email:"111@w.pl"},
    {nick:"222", email:"222@w.pl"},
    {nick:"333", email:"333@w.pl"}
 ]

let backButton = "<a href='/'><button style='padding: 10px; cursor: pointer;'>&lt; POWRÓT</button></a>"

app.use(bodyParser.urlencoded({extended: true}));

app.get("/", function(req, res){
    res.sendFile(path.join(__dirname + "/static/index.html"))
})

app.post("/addUser", function(req, res){
    let message = ""
    let canAdd = true
    if(req.body.email.includes("@") == false || req.body.email.includes(".") == false){
        message = "Podano błędny email"
    } else {
        for ( let i = 0; i < users.length; i++){
            if(users[i].email == req.body.email){
                canAdd = false
            }
        }
        if(canAdd){
            users.push({nick: req.body.nick, email:req.body.email})
            message = "Witaj "+ req.body.nick +". Twój email został dodany do bazy"
            console.log(users)
        } else {
            message = "Taki mail już jest w bazie"
        }
    }
    res.send("<html><head></head><body>"+ message +"<br><br>"+ backButton +"</body></html>")
})

app.get("/removeUserBySelect", function(req, res){
    let emailList = [];
    for(let i = 0; i < users.length; i++){
        emailList.push(users[i].email)
    }
    let options = "";
    for(let i = 0; i<emailList.length; i++){
        options += "<option value=" + i + ">" + emailList[i] + "</option>"
    }
    let selectString = "<select name='emailsList'>"+ options +"</select>"
    res.send("<html><head></head><body>"+ backButton +"<br><br><br><form action='/removeUserBySelect' method='POST'>"+ selectString +"<br><br><button type='submit'>Usuń</button></form></body></html>")
})

app.post("/removeUserBySelect", function(req, res){
    users.splice(parseInt(req.body.emailsList), 1)
    res.send("Jeden email usunięty z bazy")
})

app.get("/removeUserByRadio", function(req, res){
    let emailList = [];
    for(let i = 0; i < users.length; i++){
        emailList.push(users[i].email)
    }
    let radios = ""
    for(let i = 0; i<emailList.length; i++){
        radios += "<input style='margin-top: 20px; transform: scale(1.5); margin-right: 10px;' type='radio' id='radio"+ i +"' name='emailRadio' value="+ i +" /><label style='font-size: 26px;' for='radio"+ i +"'>"+ emailList[i] +"</label><br>"
    }
    res.send("<html><head></head><body>"+ backButton +"<br><br><br><form action='/removeUserByRadio' method='POST'>"+ radios +"<br><br><button type='submit'>Usuń</button></form></body></html>")
})

app.post("/removeUserByRadio", function(req, res){
    console.log(req.body)
    users.splice(parseInt(req.body.emailRadio), 1)
    res.send("Jeden email usunięty z bazy")
})

app.get("/removeUserByCheckbox", function(req, res){
    let emailList = [];
    for(let i = 0; i < users.length; i++){
        emailList.push(users[i].email)
    }
    let checkboxes = ""
    for(let i = 0; i<emailList.length; i++){
        checkboxes += "<input type='checkbox' name='emailCheckbox' id='checkbox"+ i +"' value="+ i +" /><label for='checkbox"+ i +"'>"+ emailList[i] +"</label><br>"
    }
    res.send("<html><head></head><body>"+ backButton +"<br><br><br><form action='/removeUserByCheckbox' method='POST'>"+ checkboxes +"<br><br><button type='submit'>Usuń</button></form></body></html>")
})

app.post("/removeUserByCheckbox", function(req, res){
    console.log(req.body)
    for(let i = req.body.emailCheckbox.length - 1; i>=0; i--){
        users.splice(parseInt(req.body.emailCheckbox[i]), 1)
    }
    res.send(req.body.emailCheckbox.length + " emaile usunięto z bazy")
})

app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})