var express = require("express");
var app = express();
var path = require("path");
var bodyParser = require("body-parser")
const PORT = 3000;

app.use(bodyParser.urlencoded({extended: true}));

app.get("/", function(req, res){
    res.sendFile(path.join(__dirname + "/static/index.html"))
})

app.post("/handleForm", function(req, res){
    console.log(req.body)
    // res.send(req.body)
    var text = JSON.stringify(req.body)
    res.send("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Odpowiedź</title></head><body style='color:white; background:"+ req.body.color +"; font-size:50px; text-align:center;'>"+ text +"</body></html>")

})

app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})