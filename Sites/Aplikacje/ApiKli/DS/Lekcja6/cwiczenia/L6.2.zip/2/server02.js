var express = require("express");
var app = express();
var path = require("path");
const PORT = 3000;

app.get("/", function(req, res){
    res.sendFile(path.join(__dirname + "/static/index.html"))
})

app.get("/handleForm", function(req, res){
    res.send("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Odpowiedź</title></head><body style='color:white; background:"+ req.query.color +"; font-size:200px; text-align:center;'>"+ req.query.color +"</body></html>")
})

app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})