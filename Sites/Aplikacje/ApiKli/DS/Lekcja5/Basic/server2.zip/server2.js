var express = require("express");
var app = express();
const PORT = 3000;

app.get("/", function(req, res){
    console.log("Obsługa adresu /")
    res.send("Do przeglądarki '/' ")
})

app.get("/test", function(req, res){
    console.log("Obsługa adresu /test")
    res.send("Do przeglądarki '/test' ")
})
app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})