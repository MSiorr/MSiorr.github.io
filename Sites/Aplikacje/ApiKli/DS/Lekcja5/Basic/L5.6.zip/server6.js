var express = require("express");
var app = express();
var cookiseParser = require("cookie-parser");
const PORT = 3000;

app.use(cookiseParser());

app.get("/", function(req, res){
    res.cookie("cookieA", "aaa", {expires: new Date(Date.now() + 1000 * 60 * 60 * 2), httpOnly:true});
    console.log(new Date(Date.now()))
    res.send("cookieA zostało utworzone")

    console.log("cookies : ", req.cookies)
})

app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})