var express = require("express");
var app = express();
const PORT = 3000;
var path = require("path");

app.use(express.static('static'))

app.get("/", function(req, res){
    console.log("Ścieżka do katalogu głównego aplikacji: " + __dirname);
    res.sendFile(path.join(__dirname + "/Static/index.html"));
})

app.get("/strona", function(req, res){
    res.sendFile(path.join(__dirname + "/Static/index.html"));
    console.log(__dirname);
})

app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})