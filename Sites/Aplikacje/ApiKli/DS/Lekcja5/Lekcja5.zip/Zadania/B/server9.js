var express = require("express");
var app = express();
const PORT = 3000;

app.get("/", function(req, res){
    if(Object.keys(req.query).length == 0){
        res.send("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Zadanie C</title></head><body><h1>Create blocks (params: bg=color ; count=count of blocks) <br> exp. bg=red&count=3</h1></body></html>")
    } else {
        res.setHeader("Content-Type", "text/html");
        var divsString = "";
        for(let i = 0; i<req.query.count; i++){
            divsString += "<div style='color:white; text-align:center; font-size:30px; font-family:Consolas; width:100px; height:100px; display:inline-block; margin:3px; background:" + req.query.bg + ";'>" + (i+1) + "</div>";
        }
        var respondString = "<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Zadanie B</title></head><body>" + divsString + "</body></html>";
        res.send(respondString)
    }
})

app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})