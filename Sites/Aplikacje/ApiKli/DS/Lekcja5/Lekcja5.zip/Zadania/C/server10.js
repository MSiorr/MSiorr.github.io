const e = require("express");
var express = require("express");
var app = express();
const PORT = 3000;

app.get("/", function(req, res){
    if(Object.keys(req.query).length == 0){
        res.send("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Zadanie C</title></head><body><h1>Calculator Deg <=> Rad (params: degToRad=true/false ; value = int/float)</h1></body></html>")
    } else {
        if(req.query.degToRad == "true"){
            var deg = req.query.value * (180/Math.PI);
            deg = Math.round(deg*100);
            if(deg.toString()[deg.toString().length - 1] == 0){
                deg = (deg/100).toString() + "0"
                console.log("hi")
            } else {
                deg = (deg/100).toString()
            }
            res.send("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Zadanie C</title></head><body><h1>" + req.query.value + " stopni = " + deg + " radianów</h1></body></html>");
        } 
        else if(req.query.degToRad == "false") {
            var rad = req.query.value * (Math.PI/180);
            rad = Math.round(rad*100);
            if(rad.toString()[rad.toString().length - 1] == 0){
                rad = (rad/100).toString() + "0"
            } else {
                rad = (rad/100).toString()
            }
            res.send("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Zadanie C</title></head><body><h1>" + req.query.value + " radianów = " + rad + " stopni</h1></body></html>");
        }
    }
})

app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})