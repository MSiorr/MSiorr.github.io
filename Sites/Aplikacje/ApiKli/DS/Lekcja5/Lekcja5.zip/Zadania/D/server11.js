var express = require("express");
var app = express();
var path = require("path");
const PORT = 3000;

app.use(express.static("static"));

app.get("/product/:id", function(req, res){
    if(req.params.id >= 1 && req.params.id <= 3){
        res.sendFile(path.join(__dirname + "/static/products/product" + req.params.id + ".html"))
    } else {
        res.send("Brak telefonu z takim id");
    }
})


app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})