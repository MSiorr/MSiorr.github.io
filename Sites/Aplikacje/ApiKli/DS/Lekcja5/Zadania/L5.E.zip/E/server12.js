var express = require("express");
var app = express();
const PORT = 3000;

app.get("/", function(req, res){
    var tableWithNumbers = [];
    for(let i = 0; i<=100; i++){
        tableWithNumbers.push(i)
    }
    var aHrefString = "";
    for(let i = 0; i<50; i++){
        var hrefIndex = Math.floor(Math.random() * tableWithNumbers.length);
        aHrefString += "<a style='font-family:Consolas; margin:10px; font-weight:bold; color:blue; font-size:24px' href='/products/" + hrefIndex + "'>product id = " + hrefIndex + "</a>"
        tableWithNumbers.splice(hrefIndex, 1);
    }
    res.send("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Zadanie E</title></head><body>" + aHrefString + "</body></html>")
    console.log(tableWithNumbers);
})

app.get("/products/:id", function(req,res){
    res.send("<!DOCTYPE html><html><head><meta charset='UTF-8'><title>Zadanie E</title></head><body><h1>Podstrona z danymi produktu o id = " + req.params.id + "</h1></body></html>")
})

app.listen(PORT, function(){
    console.log("Start serwera na porcie" + PORT);
})